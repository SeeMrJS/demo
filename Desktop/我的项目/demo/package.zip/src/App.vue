<script setup lang="ts">
import Brace from './components/brace/index.vue'
import Minesweeper from './components/minesweeper/index.vue'
</script>

<template>
  <div>seemr</div>
  <!-- <Brace /> -->
  <Minesweeper />
</template>

<style>
html,body {
  height: 100%;
  width: 100%;
  background-color: #000;
  margin: 0;
  padding: 0;
}
body {
  display: flex;
  justify-content: center;
  align-items: center;
}

</style>

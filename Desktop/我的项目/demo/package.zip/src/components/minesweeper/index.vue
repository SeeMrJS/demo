<script setup lang="ts">
import { ref, reactive, watchEffect } from 'vue'
//单元格属性
interface BlockState {
  x: number
  y: number
  revealed?: boolean //是否翻开
  mine?: boolean
  flagged?: boolean
  adjancentMines: number
}

//初次点击
let mineGenerator = false

//按钮点击事件
function sweeperClick(block: BlockState) {
  //是否是初次点击，初次点击则初始化
  if (!mineGenerator) {
    generatorMines(block)
    mineGenerator = true
  }
  //已翻转的内容不会再翻转
  if (block.revealed) return
  //flag的内容不会被翻转
  if (block.flagged) return
  //翻转到炸弹游戏结束
  if (block.mine) {
    block.revealed = true
    return mineBoom()
  }
  //翻开
  block.revealed = true
  //零方格展开
  expendZero(block)
}

//右键点击事件
function onRightClick(block: BlockState) {
  if (block.revealed) return
  block.flagged = !block.flagged
}

//点击到0的时候 会将周围的全部翻开
function expendZero(block: BlockState) {
  if (block.adjancentMines) return  //不为0则不展开

  getSiblings(block).forEach(s => {
    if (!s.revealed) {
      s.flagged = false //展开时清空上面的🚩
      s.revealed = true
      expendZero(s)
    }
  })
}

//失败
function mineBoom() {
  state.forEach(row => {
    row.forEach(item => {
      item.flagged = false
      item.revealed = true
    })
  })
}

//矩阵
const WEIGH = 10
const HEIGHT = 10
const state = reactive(Array.from(
  { length: HEIGHT },
  (_, x) => Array.from(
    { length: WEIGH },
    (_, y): BlockState => ({ x, y, adjancentMines: 0, revealed: false })
  )
))

//生成炸弹
function generatorMines(initial: BlockState) {
  for (let row of state) {
    for (let item of row) {
      //当第一次点击的时候，对被点击的点四周进行处理
      if (Math.abs(initial.x - item.x) <= 1) continue
      if (Math.abs(initial.y - item.y) <= 1) continue
      item.mine = (Math.random() < 0.2)
    }
  }
  //计算格子周围的炸弹数量
  genneratorMinesNumber()
}

//计算各自周围的炸弹数量
let directions = [
  [-1, -1],
  [-1, 0],
  [-1, 1],
  [0, -1],
  [0, 1],
  [1, -1],
  [1, 0],
  [1, 1]
]

function genneratorMinesNumber() {
  state.forEach((row) => {
    row.forEach((block) => {
      if (block.mine) return
      getSiblings(block).forEach(b => {
        if (b.mine) block.adjancentMines += 1
      })
    })
  })
}

function getSiblings(block: BlockState) {
  return directions
    .map(([dx, dy]) => {
      let y = block.y + dy
      let x = block.x + dx
      if (x < 0 || x >= WEIGH || y < 0 || y >= HEIGHT) return undefined
      return state[x][y]
    })
    .filter(Boolean) as BlockState[]
}

//检查是否胜利
function checkGameStatus() {
  const blocks = state.flat()
  if (blocks.every(block => block.revealed || block.flagged)) {
    if (blocks.some(block => !block.mine && block.flagged))
      alert('YOU CHEAT')
    else
      alert("YOU WIN")
  }
}

//监听游戏进度
watchEffect(checkGameStatus)

//不同数量下的文字颜色
const fontColor = [
  "green", //占位
  "skyblue",
  "yellow",
  "orange",
  "red",
  "pink"
]

</script>

<template>
  <div class="mine-sweeper">
    <header>Minesweeper</header>
    <div class="row" v-for="row in state">
      <div
        class="button"
        v-for="i in row"
        :class="{
          bg: i.revealed && i.mine,
          revealedBg: i.revealed && !i.mine
        }"
        @click="sweeperClick(i)"
        @contextmenu.prevent="onRightClick(i)"
      >
        <span v-if="i.flagged">🚩</span>
        <span
          v-else-if="i.revealed"
          :style="{
            'color': fontColor[i.adjancentMines],
          }"
        >{{ i.mine ? '💣' : (i.adjancentMines ? i.adjancentMines : "") }}</span>
      </div>
    </div>
  </div>
</template>

<style>
.mine-sweeper {
  color: #fff;
}
header {
  text-align: center;
  margin: 3rem 0;
  font-size: larger;
}
.row {
  display: flex;
}
.button {
  border: 1px solid #fff;
  width: 2.5rem;
  height: 2.5rem;
  font-size: 0.9rem;
  margin: 2px;

  background-color: #333;

  display: flex;
  justify-content: center;
  align-items: center;

  transition: all 0.3s;

  cursor: pointer;
}
.button:hover {
  background-color: #ccc;
}
.bg {
  background-color: rgba(219, 60, 60, 0.3);
}
.bg:hover {
  background-color: rgba(219, 60, 60, 1);
}
.revealedBg {
  background-color: #000;
  opacity: 0.5;
}
</style>